# Tipos de variables [Python]
# Ejercicios de práctica

# Autor: Inove Coding School
# Version: 2.0

# IMPORTANTE: NO borrar los comentarios
# que aparecen en verde con el hashtag "#"

# Ejercicios de práctica numérica

numero_1 = 5
numero_2 = 7

# Realizar la suma de las dos variables
# numero_1 y numero_2
# Almacenar el valor de la suma en una variable
# ej:
# operacion = .....

# Imprimir en pantalla el resultado de la suma
# print(....)

# Repita el procedimiento para realizar la resta
